//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// termp.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_termpTYPE                   130
#define IDD_DIALOG1                     318
#define IDB_BITMAP1                     324
#define IDB_BITMAP2                     328
#define IDB_BITMAP3                     329
#define IDB_BITMAP4                     330
#define IDB_BITMAP5                     331
#define IDB_BITMAP6                     332
#define IDB_BITMAP7                     333
#define IDB_BITMAP8                     334
#define IDB_BITMAP9                     335
#define IDB_BITMAP10                    336
#define IDB_BITMAP11                    337
#define IDB_BITMAP12                    338
#define IDB_BITMAP13                    339
#define IDB_BITMAP14                    340
#define IDB_BITMAP15                    341
#define IDB_BITMAP16                    342
#define IDB_BITMAP17                    343
#define IDB_BITMAP18                    349
#define IDB_BITMAP19                    350
#define IDB_BITMAP20                    351
#define IDB_BITMAP21                    352
#define IDB_BITMAP22                    353
#define IDC_LIST1                       1000
#define IDC_MYPICTURE                   1001
#define IDC_MYPICTURE2                  1002
#define IDC_text                        1003
#define IDC_temp_info                   1004
#define IDC_celcius                     1005
#define IDC_Curtemp                     1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        354
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
